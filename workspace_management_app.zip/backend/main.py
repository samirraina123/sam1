# FastAPI app entrypoint
