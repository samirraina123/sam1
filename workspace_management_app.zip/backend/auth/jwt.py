# JWT helper functions
