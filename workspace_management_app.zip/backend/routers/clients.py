# Client router logic
